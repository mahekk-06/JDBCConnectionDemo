import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentService service = new StudentService();

        while (true) {
            System.out.println("\n--- Student Management ---");
            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Choice: ");

            int ch;
            try { ch = Integer.parseInt(sc.nextLine().trim()); }
            catch (Exception e) { System.out.println("Enter a number."); continue; }

            switch (ch) {
                case 1:
                    System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
                    System.out.print("Name: "); String name = sc.nextLine();
                    System.out.print("Course: "); String course = sc.nextLine();
                    service.addStudent(new Student(id, name, course));
                    break;
                case 2:
                    service.showStudents();
                    break;
                case 3:
                    System.out.print("ID to search: "); int sid = Integer.parseInt(sc.nextLine());
                    Student s = service.searchStudent(sid);
                    System.out.println(s != null ? s : "Student not found.");
                    break;
                case 4:
                    System.out.print("ID to update: "); int uid = Integer.parseInt(sc.nextLine());
                    System.out.print("New name: "); String nname = sc.nextLine();
                    System.out.print("New course: "); String ncourse = sc.nextLine();
                    boolean updated = service.updateStudent(uid, nname, ncourse);
                    System.out.println(updated ? "Updated." : "Student not found.");
                    break;
                case 5:
                    System.out.print("ID to delete: "); int did = Integer.parseInt(sc.nextLine());
                    boolean deleted = service.deleteStudent(did);
                    System.out.println(deleted ? "Deleted." : "Student not found.");
                    break;
                case 6:
                    System.out.println("Goodbye!");
                    sc.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}

