package settasks;

import java.util.*;

public class DuplicateRemoval {

    public static void main(String[] args) {

        List<String> names = Arrays.asList("Aman", "Neha", "Aman", "Rohit", "Neha", "Sahil", "Aman");

        System.out.println("Original List: " + names);

        // Remove duplicates
        Set<String> uniqueNames = new HashSet<>(names);

        System.out.println("Unique Set: " + uniqueNames);

        // Convert back to list
        List<String> uniqueList = new ArrayList<>(uniqueNames);

        System.out.println("Back to List: " + uniqueList);
    }
}

