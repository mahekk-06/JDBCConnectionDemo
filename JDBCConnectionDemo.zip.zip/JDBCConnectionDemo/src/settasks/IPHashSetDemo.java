package settasks;

import java.util.*;

public class IPHashSetDemo {

    public static void main(String[] args) {

        List<String> ipList = Arrays.asList(
                "192.168.1.1", "10.0.0.1", "192.168.1.1",
                "172.16.0.5", "10.0.0.1", "8.8.8.8",
                "8.8.4.4", "172.16.0.5", "1.1.1.1", "8.8.8.8"
        );

        System.out.println("All Login Attempts:");
        System.out.println(ipList);

        Set<String> uniqueIPs = new HashSet<>(ipList);

        System.out.println("\nUnique IPs:");
        System.out.println(uniqueIPs);
    }
}

