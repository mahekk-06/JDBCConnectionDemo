import java.util.ArrayList;
import java.util.List;

public class StudentService {
    private final ArrayList<Student> list = new ArrayList<>();

    // Add
    public void addStudent(Student s) {
        list.add(s);
        System.out.println("Student added: " + s);
    }

    // Show all
    public void showStudents() {
        if (list.isEmpty()) {
            System.out.println("No students.");
            return;
        }
        for (Student s : list) {
            System.out.println(s);
        }
    }

    // Search
    public Student searchStudent(int id) {
        for (Student s : list) if (s.getId() == id) return s;
        return null;
    }

    // Update
    public boolean updateStudent(int id, String newName, String newCourse) {
        Student s = searchStudent(id);
        if (s == null) return false;
        s.setName(newName);
        s.setCourse(newCourse);
        return true;
    }

    // Delete
    public boolean deleteStudent(int id) {
        Student s = searchStudent(id);
        if (s == null) return false;
        return list.remove(s);
    }

    // Optional helper for tests
    public List<Student> getAll() {
        return new ArrayList<>(list);
    }
}

