package settasks;

import java.util.*;

class Student {
    int id;
    String name;
    String course;

    public Student(int id, String name, String course) {
        this.id = id;
        this.name = name;
        this.course = course;
    }

    // Required for HashSet to detect duplicates
    @Override
    public boolean equals(Object o) {
        Student s = (Student) o;
        return this.id == s.id && this.name.equals(s.name) && this.course.equals(s.course);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, course);
    }

    @Override
    public String toString() {
        return id + " - " + name + " - " + course;
    }
}

public class StudentDuplicateModule {

    public static void main(String[] args) {

        List<Student> list = new ArrayList<>();

        // Add duplicate students
        list.add(new Student(1, "Aman", "Java"));
        list.add(new Student(2, "Neha", "Python"));
        list.add(new Student(1, "Aman", "Java"));  // duplicate
        list.add(new Student(3, "Sahil", "C++"));
        list.add(new Student(2, "Neha", "Python")); // duplicate

        System.out.println("Original Students:");
        list.forEach(System.out::println);

        Set<Student> uniqueStudents = new HashSet<>(list);

        System.out.println("\nAfter Removing Duplicates:");
        uniqueStudents.forEach(System.out::println);
    }
}

