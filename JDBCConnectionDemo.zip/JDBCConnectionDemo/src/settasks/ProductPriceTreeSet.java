package settasks;

import java.util.*;

public class ProductPriceTreeSet {

    public static void main(String[] args) {

        TreeSet<Double> prices = new TreeSet<>();

        prices.add(49.99);
        prices.add(10.50);
        prices.add(99.75);
        prices.add(10.50); // duplicate
        prices.add(5.99);
        prices.add(100.00);

        System.out.println("Sorted Product Prices:");
        System.out.println(prices);
    }
}

